

inputname = "proteins_ranking_by_Beta-Binomial.csv"
outputname = "proteins_ranking_by_Beta-Binomial.data"

csv = read.csv(file=inputname, header=TRUE)

csv[1:3,]
size = nrow(csv)
n_attributes = ncol(csv) -2
attributes_names = colnames(csv)

cat("DY",file=outputname)
cat("\n",file=outputname,append=TRUE)

cat(size,file=outputname,append=TRUE)
cat("\n",file=outputname,append=TRUE)

cat(n_attributes,file=outputname,append=TRUE)
cat("\n",file=outputname,append=TRUE)

cat(attributes_names[2:(n_attributes+1)],file=outputname,append=TRUE,sep=";")
cat("\n",file=outputname,append=TRUE)


for(i in 1:nrow(csv)){
  cat(as.character(csv[i,1]),file=outputname,append=TRUE)  
  
  for(j in 2:ncol(csv)){
    cat(";",file=outputname,append=TRUE)
    cat(as.character(csv[i,j]), file=outputname, append=TRUE)
    
  }
    
   cat("\n",file=outputname,append=TRUE)
}



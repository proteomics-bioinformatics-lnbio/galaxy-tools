#Function for calculating vip scores
#Lina Hultin-Rosenberg 071024 lina.hultin-rosenberg@ki.se

calculate.vip.bhm = function(model,nr.lv,variables) 
{
  nr.var = length(variables)
  weights = loading.weights(model)
  vip = data.frame(vip.score=c(1:nr.var),weights=weights[,nr.lv],index=c(1:nr.var),row.names=variables)
  for (i in 1:nr.var) {
    vip$vip.score[i] = VIPjh(model,i,nr.lv)
  }
  vip.sorted = sort(vip$vip.score,decreasing=TRUE,index.return=TRUE)
  vip = vip[vip.sorted$ix,]
  return(vip)
}

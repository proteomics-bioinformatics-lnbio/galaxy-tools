#Program for pre-processing of 2DE data
#Lina Hultin-Rosenberg 091030 lina.hultin-rosenberg@ki.se

#Specify folder
folder = "full path to folder with subfolders dataset, pls optimization, pls prediction, R scripts"

#Create subfolders
folder.data = paste(folder,"dataset/",sep="")

#Load functions needed
source(paste(folder,"R scripts/select_present.r",sep=""))
source(paste(folder,"R scripts/estimate_mv.r",sep=""))

#Dataset
dataset = "prostate-colon"

#Spot filter parameters
present.level = 25
present.type = "tumorpresence"

#Missing value estimate
mv.method = "tenlowest"
mv.method.file = "_tenlowest"

dataset.name = paste(dataset,"_",var.incl,present,mv.method.file,sep="")

#Load expression and detection data
filename = paste(folder.data,dataset,"_int.txt",sep="")
int = read.delim(filename,header=TRUE,sep="\t",row.names=1)
filename = paste(folder.data,dataset,"_det.txt",sep="")
det = read.delim(filename,header=TRUE,sep="\t",row.names=1)

#Filter spots based on fraction of present spots in prostate and colon samples 
spots.present = select.present(det,present.type,present.level)
det.present = det[spots.present,]
int.present = int[spots.present,]

#Exchange missing values by the row mean or 10% lowest value
int.present = estimate.mv(int.present,det.present,mv.method)

#Take log2 of intensity values
int.present = log2(int.present+1)

#Save pre-processed data
filename = paste(folder.data,dataset.name,"_int.txt",sep="")
write.table(int.present,file=filename,col.names=NA,sep="\t")

filename = paste(folder.data,dataset.name,"_det.txt",sep="")
write.table(det.present,file=filename,col.names=NA,sep="\t")

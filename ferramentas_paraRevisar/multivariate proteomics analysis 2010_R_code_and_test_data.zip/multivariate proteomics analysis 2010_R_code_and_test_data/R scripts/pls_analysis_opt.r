#Program for performing PLS analysis of 2DE data - pls model optimization
#Lina Hultin-Rosenberg 20091030 lina.hultin-rosenberg@ki.se

#Specify folder
folder = "full path to folder with subfolders dataset, pls optimization, pls prediction, R scripts"

#Create subfolders
folder.scripts = paste(folder,"R scripts/",sep="")
folder.data = paste(folder,"dataset/",sep="")
folder.var = paste(folder,"pls optimization/variables/",sep="")
folder.success = paste(folder,"pls optimization/success/",sep="")

#Load functions and libraries needed
source(paste(folder.scripts,"bootstrap_validation.r",sep=""))
library(pls)

#Dataset
dataset = "prostate-colon"

#Spot filter parameters
present.level = 25
present.type = "tumorpresence"

#Missing value estimate
mv.method.file = "_tenlowest"

dataset.name = paste(dataset,"_",present.type,present.level,mv.method.file,sep="")

#Load expression and detection data
filename = paste(folder.data,dataset.name,"_int.txt",sep="")
int = read.delim(filename,header=TRUE,sep="\t",row.names=1)
filename = paste(folder.data,dataset.name,"_det.txt",sep="")
det = read.delim(filename,header=TRUE,sep="\t",row.names=1)

nr.spots = nrow(int)
nr.samples = ncol(int)

#Load sample information
filename = paste(folder.data,dataset,"_sampleinfo.txt",sep="")
sampleinfo = read.delim(filename,header=TRUE,row.names=1,sep="\t")

#PLS model parameters
pls.method = "oscorespls"   #PLS method
cut.off = 0.5               #Cut-off between classes
standard = FALSE            #Should data be standardised or not, TRUE or FALSE
nr.cv = 3                   #Number of cross-validation rounds (outer loop)
nr.boot = 10                #Number of bootstrap rounds (inner loop)
nr.lv.model = c(2,3)        #Number of PLS components (lv)

#Number of predictor variables to test
nr.var.max = nr.spots
nr.var = nr.var.max
nr.var.model = c(nr.var.max)
decrease = 0.05
while (nr.var>5)
{
  nr.var = round(nr.var-max(nr.var*decrease,1))
  nr.var.model = c(nr.var.model,nr.var)
}    

#Create response variable y using sample information
y = c(1:nrow(sampleinfo))
index.normal = sampleinfo$index[sampleinfo$group=="N"]
index.tumour = sampleinfo$index[sampleinfo$group=="T"]
y[index.tumour] = 1
y[index.normal] = 0

#Split data into training and test set for outer loop cross-validation (training set used to optimise PLS model and test set used to predict with final model)
cv.sets = cvsegments(N=nr.samples,k=nr.cv,type="random")

#Outer loop cross-validation
for (cv in 1:nr.cv) {

  #Change folder names
  folder.var.cv = paste(folder.var,"cv ",cv,"/",sep="")
  folder.success.cv = paste(folder.success,"cv ",cv,"/",sep="")

  test.index = cv.sets[[cv]]

  #Save test indeces
  sample.names.test = rownames(sampleinfo[test.index,])
  test.data = data.frame(index=test.index,row.names=sample.names.test)
  filename = paste(folder.var.cv,dataset.name,"_test_indeces.txt",sep="")
  write.table(test.data,file=filename,col.names=NA,sep="\t")

  #Extract expression data for PLS model optimisation
  int.train = int[,-test.index]
  
  #Create x variable
  x.train = as.matrix(t(int.train))
  
  #Create y variable
  y.train = y[-test.index]
  
  #Send input to inner loop bootstrap cross-validation
  bootstrap.validation(dataset.name,x.train,y.train,nr.cv,nr.boot,nr.lv.model,nr.var.model,pls.method,cut.off,standard,folder.var.cv,folder.success.cv,folder.scripts)

}

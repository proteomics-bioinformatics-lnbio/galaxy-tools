#Function for performing pls prediction with vip selected or random variables
#Lina Hultin-Rosenberg 20091030 lina.hultin-rosenberg@ki.se

pls.predict.vip = function(data.train,data.test,nr.lv,nr.var,pls.method,select.method,cut.off,standard,filename)
{
    
  y.train = data.train$y
  y.test = data.test$y
  variables = colnames(data.train$x)  
        
  if (standard)
  {
    #Center and scale data
    x.train.scaled = stdize(data.train$x,scale=TRUE,center=TRUE)
    x.test.scaled = predict(x.train.scaled,data.test$x)
    y.train.centered = data.train$y-mean(data.train$y)
    y.test.centered = data.test$y-mean(data.train$y)
    data.train$x = x.train.scaled
    data.train$y = y.train.centered
    data.test$x = x.test.scaled
    data.test$y = y.test.centered
  } 
         
  #Select variables
  data.train.select = data.train
  data.test.select = data.test
  if (select.method=="vip") {
       
    model.train = plsr(y~x,nr.lv,data=data.train,method=pls.method,scale=FALSE,validation="none",model=TRUE,x=TRUE,y=TRUE)
    vip = calculate.vip.bhm(model.train,nr.lv,variables)
    index.select = vip$index[1:nr.var]
    x.select =  data.train.select$x[,index.select]
    data.train.select$x = x.select
    x.select = data.test.select$x[,index.select]
    data.test.select$x = x.select
  } else if (select.method=="random") {
  
    index = c(1:length(variables))
    index.select = sample(index,size=nr.var)
    x.select =  data.train.select$x[,index.select]
    data.train.select$x = x.select
    x.select = data.test.select$x[,index.select]
    data.test.select$x = x.select
  } 
  
  #Save vip scores
  if (select.method!="random") {
    vip.select = vip[1:nr.var,]
    write.table(vip.select,file=filename,col.names=NA,sep="\t")
  }
        
  #Build pls model and predict using selected variables
  model.train = plsr(y~x,nr.lv,data=data.train.select,method=pls.method,scale=FALSE,validation="none",model=TRUE,x=TRUE,y=TRUE)
  y.pred = predict(model.train,data.test.select$x,ncomp=1:nr.lv,type="response")[,,nr.lv]
        
  if (standard)
  {
    #Rescale predicted y
    y.pred = y.pred+mean(y.train)
  }
  y.pred.01 = y.pred
  y.pred.01[y.pred.01<=cut.off] = 0
  y.pred.01[y.pred.01>cut.off] = 1
  result.table = table(y.test,y.pred.01)
  if (length(y.pred.01[y.pred.01==0])==0) {
    zero.matrix = matrix(data=0,ncol=1,nrow=2)
    result.matrix = cbind(zero.matrix,result.table[,1])
    colnames(result.matrix) = c("0","1")
  } else if (length(y.pred.01[y.pred.01==1])==0) {
    zero.matrix = matrix(data=0,ncol=1,nrow=2)
    result.matrix = cbind(result.table[,1],zero.matrix)
    colnames(result.matrix) = c("0","1")
  } else {
    result.matrix = cbind(result.table[,1],result.table[,2])
    colnames(result.matrix) = c("0","1")
  }
  sensitivity = result.matrix[2,2]/sum(result.matrix[2,1],result.matrix[2,2])
  specificity = result.matrix[1,1]/sum(result.matrix[1,1],result.matrix[1,2])
  g.mean = sqrt(sensitivity*specificity)
  success.measures = c(result.matrix[1,1],result.matrix[1,2],result.matrix[2,1],result.matrix[2,2],sensitivity,specificity,g.mean)
  return.list = list(success=success.measures,train=data.train.select,test=data.test.select)
  return(return.list)
}
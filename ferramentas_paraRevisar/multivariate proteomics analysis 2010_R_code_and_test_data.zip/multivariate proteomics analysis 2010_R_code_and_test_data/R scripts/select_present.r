#Function for selecting spots present in certain fractions of data
#Lina Hultin-Rosenberg 20081118 lina.hultin-rosenberg@ki.se 

select.present = function(det.data,select.method,present.level)
{

  if (select.method=="totalpresence") {
    spots.present = rownames(det.data[det.data$present.percent>=present.level,])
  }
  if (select.method=="cohortpresence") {
      spots.present.p.n = rownames(det.data[det.data$present.percent.p.n>=present.level,])
      spots.present.p.t = rownames(det.data[det.data$present.percent.p.t>=present.level,])
      spots.present.c.n = rownames(det.data[det.data$present.percent.c.n>=present.level,])
      spots.present.c.t = rownames(det.data[det.data$present.percent.c.t>=present.level,])
      spots.present = c(spots.present.p.n,spots.present.p.t,spots.present.c.n,spots.present.c.t)
      spots.present = spots.present[!duplicated(spots.present)]
  }
  if (select.method=="cohort+tumorpresence") {
      spots.present.p.n = rownames(det.data[det.data$present.percent.p.n>=present.level,])
      spots.present.p.t = rownames(det.data[det.data$present.percent.p.t>=present.level,])
      spots.present.p = c(spots.present.p.n,spots.present.p.t)
      spots.present.p = spots.present.p[!duplicated(spots.present.p)]
      spots.50.c = rownames(det.data[det.data$present.percent.c>=50,])
      spots.present.p = spots.present.p[spots.present.p%in%spots.50.c]

      spots.present.c.n = rownames(det.data[det.data$present.percent.c.n>=present.level,])
      spots.present.c.t = rownames(det.data[det.data$present.percent.c.t>=present.level,])
      spots.present.c = c(spots.present.c.n,spots.present.c.t)
      spots.present.c = spots.present.c[!duplicated(spots.present.c)]
      spots.50.p = rownames(det.data[det.data$present.percent.p>=50,])
      spots.present.c = spots.present.c[spots.present.c%in%spots.50.p]

      spots.present = c(spots.present.p,spots.present.c)
      spots.present = spots.present[!duplicated(spots.present)]
  }
  if (select.method=="cohortpresence_all") {
      spots.present.p.n = rownames(det.data[det.data$present.percent.p.n>=present.level,])
      det.present.p.t = det.data[spots.present.p.n,]
      spots.present.p.t = rownames(det.present.p.t[det.present.p.t$present.percent>=present.level,])
      det.present.c.n = det.data[spots.present.p.t,]
      spots.present.c.n = rownames(det.present.c.n[det.present.c.n$present.percent>=present.level,])
      det.present.c.t = det.data[spots.present.c.n,]
      spots.present = rownames(det.present.c.t[det.present.c.t$present.percent>=present.level,])
    }
    if (select.method=="tumorpresence") {
      spots.present.p = rownames(det.data[det.data$present.percent.p>=present.level,])
      det.present = det.data[spots.present.p,]
      spots.present = rownames(det.present[det.present$present.percent.c>=present.level,])
    }
    return(spots.present)
}


#Program for performing PLS analysis of 2DE data - pls prediction using optimal model
#Lina Hultin-Rosenberg 20091030 lina.hultin-rosenberg@ki.se

#Specify folder
folder = "full path to folder with subfolders dataset, pls optimization, pls prediction, R scripts"

#Create subfolders
folder.scripts = paste(folder,"R scripts/",sep="")
folder.data = paste(folder,"dataset/",sep="")
folder.var = paste(folder,"pls optimization/variables/",sep="")
folder.pred = paste(folder,"pls prediction/",sep="")

#Load functions and libraries needed
source(paste(folder.scripts,"calculate_vip_bhm.r",sep=""))
source(paste(folder.scripts,"vip.r",sep=""))
library(pls)

#Dataset
dataset = "prostate-colon"

#Spot filter parameters
present.level = 25
present.type = "tumorpresence"

#Missing value estimate
mv.method.file = "_tenlowest"

dataset.name = paste(dataset,"_",present.type,present.level,mv.method.file,sep="")

#Load expression and detection data
filename = paste(folder.data,dataset.name,"_int.txt",sep="")
int = read.delim(filename,header=TRUE,sep="\t",row.names=1)
filename = paste(folder.data,dataset.name,"_det.txt",sep="")
det = read.delim(filename,header=TRUE,sep="\t",row.names=1)

#Load sample information
filename = paste(folder.data,dataset,"_sampleinfo.txt",sep="")
sampleinfo = read.delim(filename,header=TRUE,row.names=1,sep="\t")

#PLS model parameters
pls.method = "oscorespls"   #PLS method
cut.off = 0.5               #Cut-off between classes
standard = FALSE            #Should data be standardised or not, TRUE or FALSE
nr.cv = 3                   #Number of cross-validation rounds (outer loop)
nr.boot = 10                #Number of bootstrap rounds (inner loop) 
nr.lv = 3                   #Number of PLS components (lv) in optimal PLS model
nr.var = 51                 #Number of predictor variables in optimal PLS model

#Stable variables level
stable.level = 50

#Load data for cv rounds
success.measures = matrix(data=0,nrow=nr.cv,ncol=7)
colnames(success.measures) = c("TN","FN","FP","TP","sensitivity","specificity","geometric mean")

#Outer loop cross-validation
for (i.cv in 1:nr.cv) {

  folder.var.cv = paste(folder.var,"cv ",i.cv,"/",sep="")
  folder.pred.cv = paste(folder.pred,"cv ",i.cv,"/",sep="")

  #Load training and test indeces from file
  filename = paste(folder.var.cv,dataset.name,"_test_indeces.txt",sep="")
  data.test =  read.delim(filename,header=TRUE,row.names=1,sep="\t")
  test.index = data.test$index

  #Create response variable y using sample info
  y = c(1:nrow(sampleinfo))
  index.normal = sampleinfo$index[sampleinfo$group=="N"]
  index.tumour = sampleinfo$index[sampleinfo$group=="T"]
  y[index.normal] = 0
  y[index.tumour] = 1
  y.test = y[test.index]
  y.train = y[-test.index]

  #Extract expression data for training and test set
  int.test = int[,test.index]
  int.train = int[,-test.index]

  #Create x variable
  x.train = as.matrix(t(int.train))
  x.test =  as.matrix(t(int.test))

  #Select final variables based on stability over bootstrap rounds
  variables = rownames(int)
  variables.index = data.frame(index=c(1:length(variables)),row.names=variables)
  var.stable = data.frame(nr.select=rep(0,length(variables)),percent.select=rep(0,length(variables)),index=c(1:length(variables)),row.names=variables)

  #Open vip files for certain model
  vip.files = list.files(path=folder.var.cv,pattern=paste(mv.method.file,"_",nr.lv,"lv_",nr.var,"var(.*)vip.txt",sep=""),full.names=TRUE)
  for (vip.file in vip.files) {
    vip.data = read.delim(vip.file,header=TRUE,row.names=1,sep="\t")
    var.stable[rownames(vip.data),]$nr.select = var.stable[rownames(vip.data),]$nr.select+1
  }
  var.stable$percent.select = (var.stable$nr.select/nr.boot)*100
  index.select = var.stable$index[var.stable$percent.select>=stable.level]
  x.train.select = x.train[,index.select]
  x.test.select = x.test[,index.select]

  if (standard) {

    #Scale data
    x.train.scaled = stdize(x.train.select,scale=TRUE,center=TRUE)
    x.test.scaled = predict(x.train.scaled,x.test.select)
    y.train.centered = y.train-mean(y.train)
    y.test.centered = y.test-mean(y.train)
  } else {
    x.train.scaled = x.train.select
    x.test.scaled = x.test.select
    y.train.centered = y.train
    y.test.centered = y.test
  }

  #Create data.frame for pls analysis
  pls.data.train.select = data.frame(x=I(x.train.scaled),y=y.train.centered)

  #Use selected variables to predict test set
  model.train = plsr(y~x,nr.lv,data=pls.data.train.select,method=pls.method,scale=FALSE,validation="none",model=TRUE,x=TRUE,y=TRUE)
  y.pred = predict(model.train,x.test.scaled,ncomp=1:nr.lv,type="response")[,,nr.lv]

  #Get VIP scores for selected variables
  variables = colnames(pls.data.train.select$x)
  vip = calculate.vip.bhm(model.train,nr.lv,variables)
  vip.sorted = vip[variables,]

  #Save stable variables
  filename = paste(folder.pred.cv,dataset.name,"_",nr.lv,"lv_",nr.var,"var_stable_var.txt",sep="")
  var.stable.save = var.stable[var.stable$percent.select>=stable.level,c(1,2)]
  var.stable.save = cbind(var.stable.save,vip.sorted[,c(1,2)])
  write.table(var.stable.save,file=filename,col.names=NA,sep="\t")

  if (standard)
  {
    #Rescale predicted y
    y.pred = y.pred+mean(y.train)
  }

  #Calculate success measures
  y.pred.01 = y.pred
  y.pred.01[y.pred.01<=cut.off] = 0
  y.pred.01[y.pred.01>cut.off] = 1
  result.table = table(y.test,y.pred.01)
  if (length(y.pred.01[y.pred.01==0])==0) {
    zero.matrix = matrix(data=0,ncol=1,nrow=2)
    result.matrix = cbind(zero.matrix,result.table[,1])
    colnames(result.matrix) = c("0","1")
  } else if (length(y.pred.01[y.pred.01==1])==0) {
    zero.matrix = matrix(data=0,ncol=1,nrow=2)
    result.matrix = cbind(result.table[,1],zero.matrix)
    colnames(result.matrix) = c("0","1")
  } else if (length(y.test[y.test==0])==0) {
    zero.matrix = matrix(data=0,ncol=2,nrow=1)
    result.matrix = rbind(zero.matrix,result.table[1,])
    colnames(result.matrix) = c("0","1")
  } else if (length(y.test[y.test==1])==0) {
    zero.matrix = matrix(data=0,ncol=2,nrow=1)
    result.matrix = rbind(result.table[1,],zero.matrix)
    colnames(result.matrix) = c("0","1")
  } else {
    result.matrix = cbind(result.table[,1],result.table[,2])
    colnames(result.matrix) = c("0","1")
  }
  sensitivity = result.matrix[2,2]/sum(result.matrix[2,1],result.matrix[2,2])
  specificity = result.matrix[1,1]/sum(result.matrix[1,1],result.matrix[1,2])
  g.mean = sqrt(sensitivity*specificity)
  success.measures[i.cv,] = c(result.matrix[1,1],result.matrix[1,2],result.matrix[2,1],result.matrix[2,2],sensitivity,specificity,g.mean)

  #Save predicted y
  filename = paste(folder.pred.cv,dataset.name,"_",nr.lv,"lv_",nr.var,"var_pred_values.txt",sep="")
  pred = data.frame(tumour_class=sampleinfo[test.index,]$tumour_group,y=y.test,pred=y.pred,pred_01=y.pred.01,row.names=rownames(sampleinfo[test.index,]))
  write.table(pred,file=filename,col.names=NA,sep="\t")

  #Plot predicted values
  filename = paste(folder.pred.cv,dataset.name,"_",nr.lv,"lv_",nr.var,"var_pred_values_boxplot.tif",sep="")
  tiff(file=filename)
  title = "Boxplot of predicted y"
  boxplot(pred~y,pred,main=title,xlab="y",ylab="predicted y")
  dev.off()
}

#Save success measures
filename = paste(folder.pred,dataset.name,"_",nr.lv,"lv_",nr.var,"var_success_measures.txt",sep="")
write.table(success.measures,file=filename,col.names=NA,sep="\t")
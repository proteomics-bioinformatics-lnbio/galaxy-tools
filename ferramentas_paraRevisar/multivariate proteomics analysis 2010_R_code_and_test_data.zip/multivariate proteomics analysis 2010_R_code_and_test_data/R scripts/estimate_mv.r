#Function for estimating missing values
#Lina Hultin-Rosenberg 081125 lina.hultin-rosenberg@ki.se

estimate.mv = function(exp.data,mv.data,method)
{
  nr.spots = nrow(exp.data)

  for (i in 1:nr.spots) {
    exp.spot = exp.data[i,]
    mv.spot = mv.data[i,]
    exp.spot.present = exp.spot[mv.spot=="P"]

    if (method=="tenlowest") {
      exp.spot.present.sort = sort(exp.spot.present)
      nr.values = length(exp.spot.present)
      lowest = round(0.1*nr.values)
      mv.estimate = exp.spot.present.sort[lowest]
    } else if (method=="rowmean") {
      mv.estimate = mean(exp.spot.present)
    } else if (method=="rowmedian") {
      mv.estimate = median(exp.spot.present)
    } else if (method=="nan") {
      mv.estimate = NA
    } else {
      mv.estimate = 0
    }
    mv = which(mv.spot=="A")
    exp.data[i,mv] = mv.estimate
  }

  return(exp.data)
}


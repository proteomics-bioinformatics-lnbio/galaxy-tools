#Function for plotting mean success measures for inner loop bootstrap validation
#Lina Hultin-Rosenberg 20091030 lina.hultin-rosenberg@ki.se

plot.pls.success = function(success,success.rnd,filename,success.type)
{
  nr.lv = ncol(success)
  nr.lv.model = colnames(success)
  nr.var.model = rownames(success)

  #Plot success measures
  tiff(file=filename)

  #Create vectors for plotting
  x.var = c(1:length(nr.var.model))
  j = 1
  x.select = c()
  while(j<=length(x.var)) {
    x.select = c(x.select,j)
    j = j+4
  }

  plot(x.var,success[,1],main=NULL,xaxt="n",type="l",lty=1,lwd=2,xlab="Number of variables",ylab=success.type,ylim=c(0,1))

  #Plot data for VIP selected variables
  for (i in 2:nr.lv)
  {
    lines(x.var,success[,i],lty=i,lwd=2)
  }

  #Plot data for randomly selected variables
  for (i in 1:nr.lv)
  {
    lines(x.var,success.rnd[,i],lty=i,lwd=2,col=gray(0.6))
  }
  
  #Add new x-axis
  axis(1,at=x.var[x.select],labels=nr.var.model[x.select])
  legend.txt = c(paste(nr.lv.model,"VIP",sep=" "),paste(nr.lv.model,"rnd var",sep=" "))
  legend(1,0,yjust=0,legend.txt,lty=c(1:nr.lv),lwd=2,col=c(rep(1,nr.lv),rep(gray(0.6),nr.lv)))
  dev.off()
}
#Function to perform bootstrap validation of PLS model using different number of PLS components and predictor variables
#Lina Hultin-Rosenberg 20091030 lina.hultin-rosenberg@ki.se

bootstrap.validation = function(dataset,x.data,y.data,nr.cv,nr.boot,nr.lv.model,nr.var.model,pls.method,cut.off,standard,folder.var,folder.success,folder.scripts)
{

  #Load functions needed
  source(paste(folder.scripts,"bootstrap_validation.r",sep=""))
  source(paste(folder.scripts,"calculate_vip_bhm.r",sep=""))
  source(paste(folder.scripts,"pls_predict_vip.r",sep=""))
  source(paste(folder.scripts,"vip.r",sep=""))
  source(paste(folder.scripts,"plot_pls_success.r",sep=""))

  #Create arrays and matrices for collecting success measures
  A = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  B = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  C = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  D = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  
  sensitivity = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  specificity = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  g.mean = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))

  sensitivity.rnd.var = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  specificity.rnd.var = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))
  g.mean.rnd.var = array(data=NA,dim=c(nr.boot,length(nr.lv.model),length(nr.var.model)),dimnames=c("boot","lv","var"))

  success.dimnames = list(rownames=nr.var.model,colnames=paste(nr.lv.model,"lv",sep=" "))
  sensitivity.mean = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  specificity.mean = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  g.mean.mean = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  sensitivity.sd = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  specificity.sd = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  g.mean.sd = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)

  sensitivity.mean.rnd.var = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  specificity.mean.rnd.var = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)
  g.mean.mean.rnd.var = matrix(data=0,nrow=length(nr.var.model),ncol=length(nr.lv.model),dimnames=success.dimnames)

  #Inner loop bootstrap validation, nr.boot rounds
  for (i in 1:nr.boot)      
  {

    nr.samples = nrow(x.data)
    class.0 = 0
    class.1 = 0
    
    #Create random training and test set (make sure each test set contains at least one sample from each tumour type)
    while (class.0<1 | class.1<1)
    {
      cv.sets = cvsegments(N=nr.samples,k=nr.cv,type="random")

      class.0 = length(which(y.data[cv.sets[[1]]]==0))
      class.1 = length(which(y.data[cv.sets[[1]]]==1))
    }
    test.index = cv.sets[[1]]

    #Create x variable for training and test
    x.train = x.data[-test.index,]
    x.test =  x.data[test.index,]

    #Create y variable for training and test
    y.train = y.data[-test.index]
    y.test = y.data[test.index]

    #Create data.frame to use in pls analysis
    pls.data.train = data.frame(x=I(x.train),y=y.train)
    pls.data.test = data.frame(x=I(x.test),y=y.test)

    j = 1
    for (nr.lv in nr.lv.model)      #Different number of PLS components
    {
      pls.data.train.select = pls.data.train
      pls.data.test.select = pls.data.test

      k = 1
      for (nr.var in nr.var.model)    #Different number of predictor variables
      {

        #Train PLS model using training set and evaulate on test set
        
        #Original data, VIP selected variables
        filename.var = paste(folder.var,dataset.name,"_",nr.lv,"lv_",nr.var,"var_",i,"boot_vip.txt",sep="")
        pls.predict = pls.predict.vip(pls.data.train.select,pls.data.test.select,nr.lv,nr.var,pls.method,"vip",cut.off,standard,filename.var)
          
        #Original data, randomly picked variables
        pls.predict.rnd.var = pls.predict.vip(pls.data.train,pls.data.test,nr.lv,nr.var,pls.method,"random",cut.off,standard,filename.var)

        #Extract dataset with selected variables
        pls.data.train.select = pls.predict$train
        pls.data.test.select = pls.predict$test

        #Extract success measures and save in arrays
        A[i,j,k] = pls.predict$success[1]
        B[i,j,k] = pls.predict$success[2]
        C[i,j,k] = pls.predict$success[3]
        D[i,j,k] = pls.predict$success[4]
        sensitivity[i,j,k] = pls.predict$success[5]
        specificity[i,j,k] = pls.predict$success[6]
        g.mean[i,j,k] = pls.predict$success[7]

        sensitivity.rnd.var[i,j,k] = pls.predict.rnd.var$success[5]
        specificity.rnd.var[i,j,k] = pls.predict.rnd.var$success[6]
        g.mean.rnd.var[i,j,k] = pls.predict.rnd.var$success[7]
        
        k = k+1
      }
      j = j+1
    }
  }

  #Collect results over bootstrap rounds
  j = 1
  for (nr.lv in nr.lv.model)
  {
    k = 1
    for (nr.var in nr.var.model)
    {
      success.lv.var = cbind(A[,j,k],B[,j,k],C[,j,k],D[,j,k],sensitivity[,j,k],specificity[,j,k],g.mean[,j,k])
      rownames(success.lv.var) = paste(c(1:nr.boot),"boot",sep=" ")
      colnames(success.lv.var) = c("TN","FN","FP","TP","sensitivity","specificity","geometric mean")
      success.lv.var.rnd.var = cbind(sensitivity.rnd.var[,j,k],specificity.rnd.var[,j,k],g.mean.rnd.var[,j,k])

      #Save success measures for each nr.lv-nr.var combination
      filename = paste(folder.success,dataset,"_",nr.lv,"lv_",nr.var,"var_success_measures.txt",sep="")
      write.table(success.lv.var,file=filename,col.names=NA,sep="\t")

      #Calculate mean and stdev over bootstrap rounds
      success.mean = apply(success.lv.var,2,mean)
      success.sd = apply(success.lv.var,2,sd)
      success.mean.rnd.var = apply(success.lv.var.rnd.var,2,mean)
      
      sensitivity.mean[k,j] = success.mean[5]
      sensitivity.sd[k,j] = success.sd[5]
      sensitivity.mean.rnd.var[k,j] = success.mean.rnd.var[1]
      specificity.mean[k,j] = success.mean[6]
      specificity.sd[k,j] = success.sd[6]
      specificity.mean.rnd.var[k,j] = success.mean.rnd.var[2]
      g.mean.mean[k,j] = success.mean[7]
      g.mean.sd[k,j] = success.sd[7]
      g.mean.mean.rnd.var[k,j] = success.mean.rnd.var[3]
      k = k+1
    }
    j = j+1
  }

  #Save mean success measures
  filename = paste(folder.success,dataset,"_sensitivity_mean.txt",sep="")
  write.table(sensitivity.mean,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_sensitivity_sd.txt",sep="")
  write.table(sensitivity.sd,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_sensitivity_rnd_var.txt",sep="")
  write.table(sensitivity.mean.rnd.var,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_specificity_mean.txt",sep="")
  write.table(specificity.mean,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_specificity_sd.txt",sep="")
  write.table(specificity.sd,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_specificity_rnd_var.txt",sep="")
  write.table(specificity.mean.rnd.var,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_gmean_mean.txt",sep="")
  write.table(g.mean.mean,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_gmean_sd.txt",sep="")
  write.table(g.mean.sd,file=filename,col.names=NA,sep="\t",)
  filename = paste(folder.success,dataset,"_gmean_rnd_var.txt",sep="")
  write.table(g.mean.mean.rnd.var,file=filename,col.names=NA,sep="\t",)

  #Plot mean success measures for VIP selected variables and random variables
  
  #Sensitivity
  filename = paste(folder.success,dataset,"_sensitivity_plot.tif",sep="")
  plot.pls.success(sensitivity.mean,sensitivity.mean.rnd.var,filename,"Sensitivity")
 
  #Specificity
  filename = paste(folder.success,dataset,"_specificity_plot.tif",sep="")
  plot.pls.success(specificity.mean,specificity.mean.rnd.var,filename,"Specificity")
 
  #Geometric mean
  filename = paste(folder.success,dataset,"_gmean_plot.tif",sep="")
  plot.pls.success(g.mean.mean,g.mean.mean.rnd.var,filename,"Geometric mean")
}
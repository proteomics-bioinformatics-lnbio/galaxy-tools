Concatenate 2 fasta files in a tail-head manner

TEST

Upload:
	- Select 2 fasta files to concatenate;
Execute
	
